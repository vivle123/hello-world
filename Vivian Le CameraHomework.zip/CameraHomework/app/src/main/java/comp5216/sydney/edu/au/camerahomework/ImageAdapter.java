package comp5216.sydney.edu.au.camerahomework;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ImageAdapter extends BaseAdapter {
    private Context mContext;
    private final String[] fileNames;
    private final String[] filePaths;




    public ImageAdapter (Context c, String[] fNames, String[] fPaths) {
        mContext = c;
        fileNames = fNames;
        filePaths = fPaths;

    }

    @Override
    public int getCount() {
        return fileNames.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    @Override

    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;

        if (convertView == null) {


            Bitmap bmp = BitmapFactory.decodeFile(filePaths[position]);




            imageView = new ImageView(mContext);


            imageView.setImageBitmap(bmp);


            imageView.setLayoutParams(new ViewGroup.LayoutParams(150, 150));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8, 8, 8, 8);
        } else {
            imageView = (ImageView) convertView;
        }


        return imageView;
    }



}
