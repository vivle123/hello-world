package comp5216.sydney.edu.au.camerahomework;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class EditPhoto extends AppCompatActivity {


   protected void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
       setContentView(R.layout.edit_view);

   }


    public void onCancelEdit (View v) {
        finish();
    }
}
