package comp5216.sydney.edu.au.camerahomework;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.camera2.CameraManager;

import android.hardware.Camera;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.EmptyStackException;



public class MainActivity extends AppCompatActivity {

    private File[] files;
    private String[] filePaths;
    private String[] fileNames;

    GridView gridView;


    private Cursor cursor;
    private int columnIndex;

    public void onTakePhotoClick (View v) {
        Intent intent = new Intent(MainActivity.this, CameraActivity.class);
        startActivity(intent);
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        File dirDownload = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM + "/newPics");
        if (dirDownload.isDirectory()) {
            //  Toast.makeText(this, "accessed dir", Toast.LENGTH_SHORT).show();
            files = dirDownload.listFiles();
            filePaths = new String[files.length];
            fileNames = new String[files.length];
            //   Toast.makeText(this, "files.length = " + files.length, Toast.LENGTH_SHORT).show();

            for (int i = 0; i < files.length; i++) {
                filePaths[i] = files[i].getAbsolutePath();
                fileNames[i] = files[i].getName();
                // Toast.makeText(this, files[i].getName(), Toast.LENGTH_SHORT).show();
            }
        }

        gridView = (GridView) findViewById(R.id.gridview);
        gridView.setAdapter(new ImageAdapter(this, fileNames, filePaths));

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(getApplicationContext(), fileNames[position], Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, EditPhoto.class);
                startActivity(intent);
            }
        });


    }





}
